import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import { ThemeProvider } from "./context/ThemeContext";
import { AuthProvider } from "./context/AuthContext";
import { LanguageProvider } from "./context/LanguageContext";
import { LocationProvider } from "./context/LocationContext";

import { HelmetProvider } from 'react-helmet-async';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
    <React.StrictMode>
        <HelmetProvider>
            <ThemeProvider>
                <AuthProvider>
                    <LanguageProvider>
                        <LocationProvider>
                            <App />
                        </LocationProvider>
                    </LanguageProvider>
                </AuthProvider>
            </ThemeProvider>
        </HelmetProvider>
    </React.StrictMode>
);